# Install 

All you have todo is copy all folder from icons to `~/.icons` and all themes to `~/.themes`. Hidden folder and hiden by default, press ctr+h to reveal them.


`duckduckgo.js` this is simple script, which enables darcula theme on duckduckgo search engine. To use it, simply copy source code to your clipboard. Then open new tab with duckduckgo. Next open console by pressing F12 and click on console. Paste the source code in the console and press enter.

